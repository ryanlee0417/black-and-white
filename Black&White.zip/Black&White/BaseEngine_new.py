# 파이게임 기반엔진
import pygame, math, os
from pygame.locals import *

global e_colorkey  # 엔티티의 배경색을 결정
e_colorkey = (200, 200, 200)

def set_global_colorkey(colorkey):
    global e_colorkey
    e_colorkey = colorkey


# 애니메이션 관련

'''
[설명]

애니메이션 시퀀스:
[[0,1],[1,1],[2,1],[3,1],[4,2]]

animation database:
{애니메이션 아이디:{이미지1,이미지2,이미지3}} * 이미지 개수는 1개씩 

animation higher database:
{엔티티 종류: {애니메이션 아이디: [[애니메이션 시퀀스], tag]}}

animation_sequence의 리턴값:

'''

animation_database={}

animation_higher_database={}

def animation_sequence(animation_info, animation_path, colorkey=(200, 200, 200), transparency=255):
    ## animation_data: [[0,1],[1,1],[2,1],[3,1],[4,2], ... , [이미지 번호, 프레임 길이]]
    # animation_database: {이미지 아이디: 이미지}
    # animation_path: .../엔티티 종류/애니메이션 이름/
    # colorkey: 이미지의 배경색
    # transparency: 투명화도

    global animation_database
    result = []
    for image_info in animation_info:  # 시퀀스의 [사진번호, 지속시간]에 대하여
        image_id = animation_path + animation_path.split('/')[-2] + '_' + str(image_info[0])
        # animation_path.split('/')[-2] -> 애니메이션 이름
        # 이미지 아이디는 애니메이션 이름_순서
        image = pygame.image.load(image_id + '.png').convert_alpha() # convert 사용시 속도 2~10배가량 빨라짐
        # image.set_colorkey(colorkey)  # 배경색 설정
        image.set_alpha(transparency)  # 이미지의 투명화 정도를 설정
        animation_database[image_id] = image.copy()  # 애니메이션 데이터베이스 딕셔너리의 이미지 아이디에 해당 이미지를 저장



        for i in range(image_info[1]):  # 프레임별 이미지 리스트를 리턴
            result.append(image_id)
    return result  # [이미지1,이미지2,이미지2,이미지3,이미지3] 이런식으로 이미지 당 배정된 프레임을 리턴함.


def get_frame(ID):
    global animation_database
    return animation_database[ID]  # 애니메이션 데이터베이스에서 이미지 아이디에 해당하는 이미지를 가져옴


def load_animations(path):  # 게임파일 내부의 모든 애니메이션을 불러오는 함수
    # path: .../data/images/entities/
    global animation_higher_database, e_colorkey
    f = open(path + 'entity_animations.txt', 'r')
    # entities/ 에 엔티티에 따른 애니메이션 정보가 있는 텍스트 파일이 존재.
    # ex: player/run/ 6;6;6;6;6;6;6;6 loop
    data = f.read()
    f.close()
    for animation in data.split('\n'):  # 엔터 기준으로 한 줄씩 데이터를 나눔
        sections = animation.split(' ')  # 띄어쓰기 기준으로 애니메이션 데이터를 나눔 -> [엔티티 종류/애니메이션 이름/, 사진당 지속시간, loop]
        animation_path = sections[0]  # 애니메이션의 경로는 엔티티 종류/애니메이션 이름/
        entity_info = animation_path.split('/')  # 경로를 [엔티티 종류,애니메이션 이름]으로 split
        entity_type = entity_info[0]  # 엔티티 종류
        print(entity_info)
        animation_id = entity_info[1]  # 애니메이션 이름
        timings = sections[1].split(';')  # 사진당 지속시간은 6;6;6과 같은 형식 -> ;기준 나누어 리스트로
        tags = sections[2].split(';')  # 애니메이션 태그 (loop 등)
        sequence = []  # 애니메이션 시퀀스는 [[0,1],[1,1],[2,1],[3,1],[4,2]]의 형태로 되어있음
        n = 0
        for timing in timings:
            sequence.append([n, int(timing)])  # [사진 번호, 지속시간] append
            n += 1
        '''시퀀스 생성 종료'''
        anim = animation_sequence(sequence, path + animation_path, e_colorkey)  # 경로는 path/엔티티종류/애니메이션이름/
        if entity_type not in animation_higher_database:  # 엔티티 종류가 animation_higher_database의 key값에 없을 경우
            animation_higher_database[entity_type] = {}  # animation_higher_database에 엔티티 종류를 key로 하고 빈 딕셔너리를 value로 한다.
        animation_higher_database[entity_type][animation_id] = [anim.copy(), tags]  # 해당 빈 딕셔너리에 애니메이션 시퀀스 저장


# 물리엔진

# 2차원 충돌 테스트
def collision_test(target_obj, obj_list):
    collision_list = []
    for obj in obj_list:
        if target_obj.colliderect(obj):
            collision_list.append(obj)
    return collision_list



# 2차원 물리 오브젝트
class physical_obj(object):

    def __init__(self, x, y, len_x, len_y):
        self.len_x = len_x
        self.len_y = len_y
        self.rect = pygame.Rect(x, y, self.len_x, self.len_y)  # 오브젝트의 직사각형 테두리를 설정
        self.x = x
        self.y = y
        self.speed=[0,0]


    def move(self, speed, terrain):

        self.speed = speed
        self.x += self.speed[0]
        self.rect.x = int(self.x)  # 좌표를 정수값으로 보정
        block_collision_list = collision_test(self.rect, terrain) # 오브젝트의 rect와 맞닿아 있는 주변 지형지물 리스트
        collision_types = {'top': False, 'bottom': False, 'right': False, 'left': False,
                           'data': []}  # 어떤 오브젝트들과 어느 방향 면이 맞닿아 있는가
        for block in block_collision_list:  # 플레이어가 블럭에 충돌중일떄
            if speed[0] > 0:  # 오브젝트가 x축의 양의 방향으로 움직이고 있었다면
                self.rect.right = block.left  # 오브젝트 사각형의 오른쪽 끝부분의 x좌표를 블럭의 왼쪽으로 고정
                collision_types['right'] = True  # 오브젝트 오른쪽에서 블럭과의 출력이 발생했다고 저장
            elif speed[0] < 0:  # 반대의 경우에도 같은 방법
                self.rect.left = block.right
                collision_types['left'] = True
            # collision_types['data'].append(block)
            self.x = self.rect.x  # 좌표를 정수값으로 보정

        # y축도 마찬가지
        self.y += self.speed[1]
        self.rect.y = int(self.y)
        block_collision_list = collision_test(self.rect, terrain)
        for block in block_collision_list:
            if self.speed[1] > 0:
                self.rect.bottom = block.top
                collision_types['bottom'] = True
            elif self.speed[1] < 0:
                self.rect.top = block.bottom
                collision_types['top'] = True
            # collision_types['data'].append(block)
            self.y = self.rect.y
        return collision_types
    def setspeed(self,new_speed):
        self.speed=new_speed
    '''
    [정리]
    move 함수
    입력: speed(이변수 리스트)와 지형지물 리스트
    실행: 플레이어의 x,y 좌표를 speed 만큼 이동,
        플레이어가 특정 블럭과 충돌하였다면 해당 블럭을 뜷고 지나갈 수 없도록 좌표를 고정
    반환: 플레이어와 다른 블럭 간의 충돌정보를 리턴
    '''

# entity stuff

def simple_entity(x, y, e_type):
    return entity(x, y, 1, 1, e_type)


def flip(img, boolean=True):
    return pygame.transform.flip(img, boolean, False)


def blit_center(surf, surf2, pos):
    x = int(surf2.get_width() / 2)
    y = int(surf2.get_height() / 2)
    surf.blit(surf2, (pos[0] - x, pos[1] - y))


class entity(physical_obj):
    global animation_database, animation_higher_database
    # animation_database: {이미지 id: 이미지} 형태입니다.
    # animation_higher_database: {엔티티 종류: {애니메이션 아이디: [[애니메이션 시퀀스], tag]}}

    def __init__(self, x, y, len_x, len_y, e_type):
        super().__init__(x, y, len_x, len_y)
        self.animation = None
        self.image = None
        self.animation_frame = 0
        self.animation_tags = []
        self.flip = False
        self.offset = [0, 0]
        self.rotation = 0
        self.type = e_type  # 애니메이션 구분용
        self.action_timer = 0
        self.action = ''
        self.set_action('idle')  # 현재 엔티티의 상태
        self.entity_data = {}
        self.alpha = None
        self.firstpos=[x,y]


    def set_pos(self, x, y): # 플레이어의 위치
        self.x = x
        self.y = y
        self.rect.x = x
        self.rect.y = y

    # def move(self, speed, terrain):
    #     collision_types = super(entity, self).move(speed, terrain)
    #     return collision_types  # 물리 오브젝트에서 collision_types를 리턴
    def getfirstpos(self):
        return self.firstpos
    def get_pos(self):
        return [self.x,self.y]
    def set_flip(self, flip): # 플레이어 좌우 뒤집힘 여부
        self.flip = flip
    def getspeed(self):
        return self.speed
    def set_animation_tags(self, tags):
        self.animation_tags = tags # 루프, 단일 등의 애니메이션 태그 정하기

    def set_animation(self, sequence): # 애니메이션 시퀀스 [이미지1,이미지2,이미지2,이미지3,이미지3]
        self.animation = sequence
        self.animation_frame = 0

    def set_action(self, action_id, force=False): # 하는 중인 행동을 특정 행동(run, attack)등으로 설정
        if (self.action == action_id) and (force == False):
            pass
        else:
            self.action = action_id
            anim = animation_higher_database[self.type][action_id]
            self.animation = anim[0] # 애니메이션 시퀀스 [이미지1,이미지2,이미지2,이미지3,이미지3]
            self.set_animation_tags(anim[1])
            self.animation_frame = 0 # 애니메이션 프레임을 초기화

    def get_action(self):
        return self.action

    def get_entity_angle(self,entity_2):
        x1 = self.x + int(self.len_x / 2)
        y1 = self.y + int(self.len_y / 2)
        x2 = entity_2.x + int(entity_2.len_x / 2)
        y2 = entity_2.y + int(entity_2.len_y / 2)
        angle = math.atan((y2 - y1) / (x2 - x1))
        if x2 < x1:
            angle += math.pi
        return angle

    def get_center(self):
        x = self.x + int(self.len_x / 2)
        y = self.y + int(self.len_y / 2)
        return [x, y]

    def clear_animation(self):
        self.animation = None

    def set_image(self, image):
        self.image = image

    def set_offset(self, offset):
        self.offset = offset

    def set_frame(self, amount):
        self.animation_frame = amount

    def handle(self):
        self.action_timer += 1
        self.change_frame(1)

    def change_frame(self, amount):
        self.animation_frame += amount
        if self.animation != None: # 애니메이션이 존재하는 객체일때
            while self.animation_frame < 0: # 애니메이션 프레임이 음수이면
                if 'loop' in self.animation_tags:
                    self.animation_frame += len(self.animation) # 애니메이션 프레임을 주어진 범위의 정수값으로 설정
                else:
                    self.animation = 0
            while self.animation_frame >= len(self.animation):
                if 'loop' in self.animation_tags:
                    self.animation_frame -= len(self.animation)
                else:
                    self.animation_frame = len(self.animation) - 1

    def get_current_img(self):
        if self.animation == None:
            if self.image != None:
                return flip(self.image, self.flip)
            else:
                return None
        else:
            return flip(animation_database[self.animation[self.animation_frame]], self.flip)

    def get_drawn_img(self):
        image_to_render = None
        if self.animation == None:
            if self.image != None:
                image_to_render = flip(self.image, self.flip).copy()
        else:
            image_to_render = flip(animation_database[self.animation[self.animation_frame]], self.flip).copy()
        if image_to_render != None:
            center_x = image_to_render.get_width() / 2
            center_y = image_to_render.get_height() / 2
            image_to_render = pygame.transform.rotate(image_to_render, self.rotation)
            if self.alpha != None:
                image_to_render.set_alpha(self.alpha)
            return image_to_render, center_x, center_y

    def display(self, surface, scroll, correction_x, correction_y):
        image_to_render = None
        if self.animation == None:
            if self.image != None:
                image_to_render = flip(self.image, self.flip).copy()
        else:
            image_to_render = flip(animation_database[self.animation[self.animation_frame]], self.flip).copy()
        if image_to_render != None:
            center_x = image_to_render.get_width() / 2
            center_y = image_to_render.get_height() / 2
            image_to_render = pygame.transform.rotate(image_to_render, self.rotation)
            if self.alpha != None:
                image_to_render.set_alpha(self.alpha)
            blit_center(surface, image_to_render, (int(self.x) - scroll[0] + self.offset[0] + center_x - correction_x,
                                                   int(self.y) - scroll[1] + self.offset[1] + center_y - correction_y))

score=0
class coin(physical_obj):
    def __init__(self,x,y,len_x,len_y,score):
        super().__init__(x,y,len_x,len_y)
        self.score=score
        self.state='Not Eaten'
    def Eaten(self):
        self.state='Eaten'

start_color=0
started=True
screen = pygame.display.set_mode((1080,720), 0, 32)
import sys
mainClock = pygame.time.Clock()
def Gameclear():
    pygame.mixer.music.fadeout(1000)
    ending = pygame.mixer.Sound("data/audio/2_Tropical.wav").play()
    gameclear_img=pygame.transform.scale(pygame.image.load('Gameclear.png'),(1080,720))
    k = 0
    key = 2
    i = 0
    a = ()
    # sum_time=sum(g.passed_time)
    # myFont = pygame.font.SysFont("arial", 30, True, False)
    # str_time = myFont.render(str(int((sum_time - sum_time%1000) // 1000)),True, (0, 0, 0))
    # str_time_rect = str_time.get_rect()
    # str_time_rect.center = (100, 100)
    while True:
        screen.fill((0,0,0))
        # if i%3==0:
        #     a=(k,0,0)
        # elif i%3==1:
        #     a=(0,k,0)
        # else:
        #     a=(0,0,k)
        #
        # if k+key>255:
        #     key=-key
        # elif k+key<0:
        #     key=-key
        #     i+=1
        # k+=key
        # myFont = pygame.font.SysFont("arial", 100, True, False)
        # str_end = myFont.render("GAME CLEAR!", True, a)
        # str_end_rect = str_end.get_rect()
        # str_end_rect.center = (540, 360)
        # screen.blit(str_end, str_end_rect)
        gameclear_img_rect=gameclear_img.get_rect()
        gameclear_img_rect.center=(540,360)
        screen.blit(gameclear_img,gameclear_img_rect)
        # screen.blit(str_time,str_time_rect)
        for event in pygame.event.get():
            if event.type==QUIT:
                pygame.quit()
                sys.exit()
        pygame.display.update()
        mainClock.tick(60)

def starting():
    global start_color,started
    key=2
    pygame.mixer.music.pause()
    while started:
        for event in pygame.event.get():
            if event.type==QUIT:
                pygame.quit()
                sys.exit()
            if event.type==KEYDOWN:
                if event.key==K_SPACE:
                    started=False
                    pygame.mixer.music.unpause()
        screen.fill((0,0,0))
        if start_color+key>255:
            key=-key
            start_color+=key
        elif start_color+key<0:
            key=-key
            start_color+=key
        else:
            start_color+=key
            myFont = pygame.font.SysFont("arial", 100, True, False)
            str_start = myFont.render("Press  Space  To  Start", True, (start_color,start_color,start_color))
            str_start_rect = str_start.get_rect()
            str_start_rect.center = (550,360)
            screen.blit(str_start, str_start_rect)
            pygame.display.update()
            mainClock.tick(60)


Stage_num=1
def SelectStage(Stage_list):
    global Stage_num
    while True:
        pygame.display.set_caption('Stage Selection')
        screen.fill((0,0,0))

        click=False
        for event in pygame.event.get():
            if event.type==QUIT:
                pygame.quit()
                sys.exit()
            if event.type==MOUSEBUTTONDOWN and event.button==1:
                click=True

        button_Stage1=pygame.Rect(0,0,150,150)
        button_Stage1.center=(300,200)
        pygame.draw.rect(screen,Stage_list[0].getcolor(),button_Stage1)
        myFont = pygame.font.SysFont("arial", 30, True, False)
        str_Stage1 = myFont.render("STAGE 1", True, Stage_list[0].getstrcolor())
        str_Stage1_rect = str_Stage1.get_rect()
        str_Stage1_rect.center = (300,200)
        screen.blit(str_Stage1, str_Stage1_rect)

        button_Stage2 = pygame.Rect(0, 0, 150, 150)
        button_Stage2.center = (600, 200)
        pygame.draw.rect(screen, Stage_list[1].getcolor(), button_Stage2)
        myFont = pygame.font.SysFont("arial", 30, True, False)
        str_Stage2 = myFont.render("STAGE 2", True, Stage_list[1].getstrcolor())
        str_Stage2_rect = str_Stage2.get_rect()
        str_Stage2_rect.center = (600, 200)
        screen.blit(str_Stage2, str_Stage2_rect)

        button_Stage3 = pygame.Rect(0, 0, 150, 150)
        button_Stage3.center = (900, 200)
        pygame.draw.rect(screen, Stage_list[2].getcolor(), button_Stage3)
        myFont = pygame.font.SysFont("arial", 30, True, False)
        str_Stage3 = myFont.render("STAGE 3", True, Stage_list[2].getstrcolor())
        str_Stage3_rect = str_Stage3.get_rect()
        str_Stage3_rect.center = (900, 200)
        screen.blit(str_Stage3, str_Stage3_rect)

        button_Stage4 = pygame.Rect(0, 0, 150, 150)
        button_Stage4.center = (400,500)
        pygame.draw.rect(screen, Stage_list[3].getcolor(), button_Stage4)
        myFont = pygame.font.SysFont("arial", 30, True, False)
        str_Stage4 = myFont.render("STAGE 4", True, Stage_list[3].getstrcolor())
        str_Stage4_rect = str_Stage4.get_rect()
        str_Stage4_rect.center = (400, 500)
        screen.blit(str_Stage4, str_Stage4_rect)

        button_Stage5 = pygame.Rect(0, 0, 150, 150)
        button_Stage5.center = (700, 500)
        pygame.draw.rect(screen, Stage_list[4].getcolor(), button_Stage5)
        myFont = pygame.font.SysFont("arial", 30, True, False)
        str_Stage5 = myFont.render("STAGE 5", True, Stage_list[4].getstrcolor())
        str_Stage5_rect = str_Stage5.get_rect()
        str_Stage5_rect.center = (700, 500)
        screen.blit(str_Stage5, str_Stage5_rect)

        if button_Stage1.collidepoint(pygame.mouse.get_pos()):
            if click:
                Stage_num=1
                break
        if button_Stage2.collidepoint(pygame.mouse.get_pos()):
            if click:
                if Stage_list[1].getstate()==True:
                    Stage_num=2
                    break
                else:
                    pass
        if button_Stage3.collidepoint(pygame.mouse.get_pos()):
            if click:
                if Stage_list[2].getstate()==True:
                    Stage_num=3
                    break
                else:
                    pass
        if button_Stage4.collidepoint(pygame.mouse.get_pos()):
            if click:
                if Stage_list[3].getstate()==True:
                    Stage_num=4
                    break
                else:
                    pass
        if button_Stage5.collidepoint(pygame.mouse.get_pos()):
            if click:
                if Stage_list[4].getstate()==True:
                    Stage_num=5
                    break
                else:
                    pass



        pygame.display.update()
        mainClock.tick(60)
class Stage:
    def __init__(self,list,num):
        self.map=list
        self.stage_number=num
        self.unlocked=False
    def getmap(self):
        return self.map
    def getstate(self):
        return self.unlocked
    def changestate(self):
        self.unlocked=True
    def getcolor(self):
        if self.unlocked==True:
            return (255,255,255)
        else:
            return (0,0,0)
    def getstrcolor(self):
        if self.unlocked==True:
            return (0,0,0)
        else:
            return (255,255,255)