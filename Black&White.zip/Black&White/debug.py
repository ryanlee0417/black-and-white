if not collision_types['bottom'] or collision_types['right'] or collision_types['left']:  # tree가 블럭 위에 없을경우
    tree.floating = True  # tree가 공중에 떠있다
    if not tree.jumping:  # 만약 tree가 점핑하고 있지 않다면?
        tree.speed[1] = -6  # 범피 점프시킴
        print('jump!')
        tree.jumping = True
    tree.speed[1] += 0.2

if collision_types['bottom']:
    tree.floating = False
    tree.jumping = False