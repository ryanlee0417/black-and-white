import pygame, sys, random  # 파이게임, sys 라이브러리 불러오기
import BaseEngine_new as e
clock = pygame.time.Clock()
import menu as m
from load_map import *
import load_map as l
import timeit

from pygame.locals import * # 파이게임 모듈 임포트
pygame.mixer.pre_init(44100, -16, 2, 128)

pygame.init()  # initiate pygame
pygame.mixer.set_num_channels(32)
pygame.display.set_caption('Black and White') # set the window name


WINDOW_SIZE = (1080, 720)  # set up window size
screen = pygame.display.set_mode(WINDOW_SIZE, 0, 32)  # initiate screen
display=pygame.Surface((300,200))


fps=60
menu_state=False
stage_selection_state=False
health=10


effect_volume=1
jump_sound = pygame.mixer.Sound('data/audio/jump.wav')
jump_sound.set_volume(effect_volume)
grass_sound = [pygame.mixer.Sound('data/audio/grass_0.wav'), pygame.mixer.Sound('data/audio/grass_1.wav')]
grass_sound[0].set_volume(effect_volume)
grass_sound[1].set_volume(effect_volume)



pygame.mixer.music.load('data/audio/music.wav')
pygame.mixer.music.set_volume(1)
pygame.mixer.music.play(-1)

dead=False


CHUNK_SIZE=8


e.load_animations('data/images/entities/')

moving_right = False
moving_left = False

air_timer=0
grass_sound_timer=0
bumpy_jump=0.5

true_scroll=[0,0]

player_y_momentum = 0

player_image=pygame.image.load('data/images/entities/player/idle/idle_0.png')
player=e.entity(15,-50,13,33, 'player')


stage_number=1
color_reverse_counter=0
restart_image=pygame.transform.scale(pygame.image.load('restart.png'),(500,200))
restart_rect=restart_image.get_rect()




time_stage_list=[]
l.Stages[0].changestate()

passed_time=[0,0,0,0,0]
timer_started=False
start_time=0

while True:  # game loop
    if not menu_state:
        if e.started:
            e.starting()
            e.SelectStage(l.Stages)
            stage_number=e.Stage_num
            load_map(stage_number)
            timer_started=not timer_started
            start_time=pygame.time.get_ticks()

        else:
            display.fill((background_color,background_color,background_color))  # clear screen by filling it with blue

            if grass_sound_timer>0:
                grass_sound_timer-=1

            true_scroll[0]+=(player.x-true_scroll[0]-150)/20
            true_scroll[1]+=(player.y-true_scroll[1]-80)/20
            scroll=true_scroll.copy()
            scroll[0]=int(scroll[0])
            scroll[1]=int(scroll[1])

            for dirt in dirt_objects:
                display.blit(dirt_image, (dirt[0] * 16 - scroll[0], dirt[1] * 16 - scroll[1]))

            for grass in grass_objects:
                display.blit(grass_image, (grass[0] * 16 - scroll[0], grass[1] * 16 - scroll[1]))

            # for background_object in background_objects:
            #     obj_rect = pygame.Rect(background_object[1][0] - scroll[0] * background_object[0],
            #                            background_object[1][1] - scroll[1] * background_object[0], background_object[1][2],
            #                            background_object[1][3])
            #     if background_object[0] == 0.5:
            #         pygame.draw.rect(display, (255, 255, 255), obj_rect)
            #     else:
            #         pygame.draw.rect(display, (0, 0, 0), obj_rect)


            for jumper in jumper_objects:
                jumper.render(display,scroll)
                if jumper.jumper_collision_test(player.rect):
                    player_y_momentum=-4

            for throne in throne_objects:
                throne.render(display, scroll)
                if throne.throne_collision_test(player.rect):
                    health -= 10
                    player_y_momentum -= 2

            if color_reverse_counter > 0:
                color_reverse_counter -= 1
                background_color += 51
                print(background_color)

            if color_reverse_counter < 0:
                color_reverse_counter += 1
                background_color -= 51

            print(passed_time[stage_number-1])
            passed_time[stage_number-1]=pygame.time.get_ticks()-start_time
            myFont = pygame.font.SysFont("arial", 30, True, False)
            str_time = myFont.render(str(int((passed_time[stage_number-1]-passed_time[stage_number-1]%1000)//1000)), True, (255-background_color,255-background_color,255-background_color))
            str_time_rect = str_time.get_rect()
            str_time_rect.center = (100,100)

            #tile rendering

            player_movement = [0, 0]

            if moving_right:
                player_movement[0]+=2
            if moving_left:
                player_movement[0]-=2
            player_movement[1]+=player_y_momentum
            player_y_momentum += 0.2
            if player_y_momentum > 3:
                player_y_momentum=3


            if player.y>300:
                health-=10

            if health<=0:
                player.set_action('death')
                dead = True
                player_movement=[0,0]
                moving_right=False
                moving_left=False
                player.set_pos(15,-50)
                health=10
                load_map(stage_number)

            else:
                if player_movement[0]>0:
                    player.set_action('run')
                    player.set_flip(False)

                if player_movement[0]==0:
                    player.set_action('idle')

                if player_movement[0]<0:
                    player.set_action('run')
                    player.set_flip(True)


            collision_types = player.move(player_movement,tile_rects)
            if collision_types['bottom']:
                player_y_momentum=0
                air_timer=0
                if player_movement[0]!=0:
                    if grass_sound_timer==0:
                        grass_sound_timer=30
                        random.choice(grass_sound).play()
            else:
                air_timer+=1


            player.change_frame(1)
            player.display(display,scroll,58,78)


            display_r = pygame.Rect(scroll[0], scroll[1], 300, 200)

            for creature in creature_objects:
                creature.display(display, scroll, 0, 42)
                creature.change_frame(1)
                if player.rect.colliderect(creature.rect):
                    health -= 100

            for tree in tree_objects:
                if 50 < abs(player.x - tree.x) < 100 and not tree.attacking:
                    tree.set_action('intro')
                if 50 > abs(player.x - tree.x):
                    tree.set_action('run')
                    tree.attacking = True

                if tree.attacking:
                    if player.x > tree.x+15:
                        tree.speed[0] = 0.9
                        tree.set_flip(True)

                    if player.x < tree.x-15:
                        tree.speed[0] = -0.9
                        tree.set_flip(False)


                if player.rect.colliderect(tree.rect):
                    player_y_momentum = -4
                    health -= 100
                tree.x+=tree.speed[0]
                tree.move(tree.speed, tile_rects)
                tree.display(display, scroll, 40, 80)
                tree.change_frame(1)


            for bumpy in bumpy_objects:
                if display_r.colliderect(bumpy.rect):
                    bumpy.set_action('run')
                    bumpy.speed[1]+=0.2
                    # bumpy.speed[0] += 0.2
                    # if bumpy.speed[0] > 3:
                    #     bumpy.speed[0] = 3
                    if player.x > bumpy.x + 5:
                        bumpy.speed[0] = 1.5
                        bumpy.set_flip(True)
                    if player.x < bumpy.x - 5:
                        bumpy.speed[0] = -1.5
                        bumpy.set_flip(False)

                    collision_types=bumpy.move(bumpy.speed, tile_rects)
                    # if collision_types['bottom']:
                    #     bumpy.speed[0]=0

                    if not collision_types['bottom'] or collision_types['right'] or collision_types['left']: #bumpy가 블럭 위에 없을경우
                        bumpy.floating=True # bumpy가 공중에 떠있다
                        if not bumpy.jumping: # 만약 bumpy가 점핑하고 있지 않다면?
                            bumpy.speed[1]=-6 # 범피 점프시킴
                            print('jump!')
                            bumpy.jumping=True
                        bumpy.speed[1]+=0.2

                    if collision_types['bottom']:
                        bumpy.floating=False
                        bumpy.jumping=False

                    if player.rect.colliderect(bumpy.rect):
                        player_y_momentum = -4
                        health -= 10
                    bumpy.display(display,scroll,0,3)
                    bumpy.change_frame(1)
                    # bumpy.jump_timer-=1
                    # bumpy.speed[1]+=0.8


            for skull in skull_objects:
                if display_r.colliderect(skull.rect): #적이 화면 내에 있다면
                    if player.x > skull.x + 5:
                        skull.set_flip(True)
                    if player.x < skull.x - 5:
                        skull.set_flip(False)
                #     collision_types = skull[1].move(skull_movement, tile_rects)
                #     if collision_types['bottom'] == True:
                #         skull[0] = 0
                #
                #     skull[1].display(display, scroll,0,-16)
                skull_speed=skull.getspeed()
                if skull.get_pos()[0]+skull_speed>skull.getfirstpos()[0]+100:
                    skull.setspeed(-skull_speed)
                elif skull.get_pos()[0]+skull_speed<skull.getfirstpos()[0]-100:
                    skull.setspeed(-skull_speed)
                skull.set_pos(skull.get_pos()[0]+skull_speed,skull.get_pos()[1])
                skull.display(display,scroll,0,0)

                if player.rect.colliderect(skull.rect):
                        player_y_momentum = -4
                        health-=10
                skull.change_frame(1)

            for pt in portals:
                pt.display(display,scroll,0,0)
                pt.change_frame(1)
                if player.rect.colliderect(pt.rect):
                    if stage_number!=5:
                        l.Stages[stage_number].changestate()
                    elif stage_number==5:
                        e.Gameclear()
                    e.SelectStage(l.Stages)
                    stage_number=e.Stage_num
                    start_time=pygame.time.get_ticks()
                    player.set_pos(15, -50)
                    player_movement=[0,0]
                    moving_right = False
                    moving_left = False
                    print(stage_number)
                    load_map(stage_number)




            for event in pygame.event.get():  # event loop
                if event.type == QUIT:  # check for window quit
                    pygame.quit()  # stop pygame
                    sys.exit()  # stop script
                if event.type == KEYDOWN:
                    if event.key== K_SPACE:
                        print('SPACEKEY')
                        if background_color==0:
                            color_reverse_counter=5
                            print('colorcounter added')
                        if background_color==255:
                            color_reverse_counter=-5
                    if event.key == K_RIGHT :
                        moving_right = True
                    if event.key == K_LEFT:
                        moving_left = True
                    if event.key == K_UP:
                        if air_timer<12:
                            jump_sound.play()
                            player_y_momentum=-4
                    if event.key == K_ESCAPE:
                        menu_state = True

                    # if event.key == K_w:
                    #     pygame.mixer.music.fadeout(1000)
                if event.type == KEYUP:
                    if event.key == K_RIGHT:
                        moving_right = False
                    if event.key == K_LEFT:
                        moving_left = False

            surf=pygame.transform.scale(display, WINDOW_SIZE)
            screen.blit(surf,(0,0))
            screen.blit(str_time, str_time_rect)
            pygame.display.update()  # update display
            clock.tick(fps)  # maintain 60 fps
    else:
        player_movement=[0,0]
        moving_right=False
        moving_left=False
        player.move(player_movement,[])
        m.main_menu()
        if m.stage_select==True:
            stage_number=e.Stage_num
            l.load_map(stage_number)
            m.stage_select=False
            player.set_pos(15, -50)
            player_movement = [0, 0]
            moving_right = False
            moving_left = False
        elif m.restart==True:
            l.load_map(stage_number)
            m.restart=False
            player.set_pos(15, -50)
            player_movement = [0, 0]
            moving_right = False
            moving_left = False
        effect_volume=m.effect_volume
        jump_sound.set_volume(effect_volume)
        grass_sound[0].set_volume(effect_volume)
        grass_sound[1].set_volume(effect_volume)
        fps=m.setfps
        menu_state=False