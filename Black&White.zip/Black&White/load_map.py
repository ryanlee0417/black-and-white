import pygame
from BaseEngine_new import Stage, entity, collision_test
import random as rd

grass_image = pygame.image.load('data/images/grass.png').convert()
grass_image.set_colorkey((128, 128, 128))
dirt_image = pygame.image.load('data/images/dirt.png').convert()
dirt_image.set_colorkey((128, 128, 128))
plant_img = pygame.image.load('data/images/plant.png').convert()
plant_img.set_colorkey((0, 199, 255))
throne_black_img=pygame.transform.scale(pygame.image.load('data/images/throne_black.png').convert_alpha(),(16,16))
throne_white_img=pygame.transform.scale(pygame.image.load('data/images/throne_white.png').convert_alpha(),(16,16))
throne_img=[throne_white_img,throne_black_img]

jumper_black_img = pygame.image.load('data/images/jumper_black.png').convert_alpha()
jumper_white_img = pygame.image.load('data/images/jumper_white.png').convert_alpha()
jumper_img = [jumper_white_img, jumper_black_img]

portal_black_list = []
portal_white_list = []

color_syntax={0:'_white',1:'_black'}

for i in range(9):
    image1 = pygame.image.load('data/images/blocks/portal_black/portal_black_' + str(i) + '.png').convert_alpha()
    image2 = pygame.image.load('data/images/blocks/portal_white/portal_white_' + str(i) + '.png').convert_alpha()
    portal_black_list.append(image1)
    portal_white_list.append(image2)


class jumper_obj():
    def __init__(self, loc, color):
        self.loc = loc
        self.color = color  # 0=black, 1=white
        self.image = jumper_img[color]

    def render(self, surf, scroll):
        surf.blit(self.image, (self.loc[0] - scroll[0], self.loc[1] - scroll[1]))

    def get_rect(self):
        return pygame.Rect(self.loc[0], self.loc[1], 8, 9)

    def jumper_collision_test(self, rect):
        jumper_rect = self.get_rect()
        return jumper_rect.colliderect(rect)

class throne_obj():
    def __init__(self,loc,color):
        self.loc=loc
        self.color=color
        self.image=throne_img[color]
    def render(self,surf,scroll):
        surf.blit(self.image,(self.loc[0] - scroll[0], self.loc[1] - scroll[1]))
    def get_rect(self):
        return pygame.Rect(self.loc[0], self.loc[1], 8, 9)
    def throne_collision_test(self, rect):
        throne_rect = self.get_rect()
        return throne_rect.colliderect(rect)

class skull_obj(entity):
    def __init__(self, x, y, color):
        self.color=color
        super().__init__(x, y, 32, 16, 'skull'+color_syntax[color])

class tree_obj(entity):
    def __init__(self, x, y, color):
        self.color=color
        self.attacking=False
        self.jumping=False
        self.attacking=False
        super().__init__(x, y, 13, 33, 'tree'+color_syntax[color])

    def move(self, speed, terrain):
        self.speed = speed
        self.x += self.speed[0]
        self.rect.x = int(self.x)  # 좌표를 정수값으로 보정
        block_collision_list = collision_test(self.rect, terrain) # 오브젝트의 rect와 맞닿아 있는 주변 지형지물 리스트
        collision_types = {'top': False, 'bottom': False, 'right': False, 'left': False,
                           'data': []}  # 어떤 오브젝트들과 어느 방향 면이 맞닿아 있는가

        # y축도 마찬가지
        self.y += self.speed[1]
        self.rect.y = int(self.y)
        block_collision_list = collision_test(self.rect, terrain)
        for block in block_collision_list:
            if self.speed[1] > 0:
                self.rect.bottom = block.top
                collision_types['bottom'] = True
            elif self.speed[1] < 0:
                self.rect.top = block.bottom
                collision_types['top'] = True
            # collision_types['data'].append(block)
            self.y = self.rect.y
        return collision_types

class bumpy_obj(entity):
    def __init__(self, x, y, color):
        self.jump_timer=0
        self.color=color
        self.floating=False
        self.jumping=False
        super().__init__(x, y, 18, 22, 'bumpy'+color_syntax[color])


class creature_obj(entity):
    def __init__(self,x,y,color):
        self.color=color
        super().__init__(x, y, 64, 30, 'creature'+color_syntax[color])

portal_name = {0: 'portal_white', 1: 'portal_black'}


class portal(entity):
    def __init__(self, x, y, len_x, len_y, e_type):
        super().__init__(x, y, len_x, len_y, e_type)


tile_index = {1: grass_image, 2: dirt_image, 3: plant_img}

TILE_SIZE = grass_image.get_width()

f = open('map.txt', 'r')
data = f.read()
f.close()

game_map = []

for map in data.split('*'):
    terrain = []
    for line in map.split():
        terrain.append(list(line))
    game_map.append(terrain)

background_objects = [[0.25, [120, 10, 70, 400]], [0.25, [280, 30, 40, 400]], [0.5, [30, 40, 40, 400]],
                      [0.5, [130, 90, 100, 400]], [0.5, [300, 80, 120, 400]]]
background_color = 0

tile_rects = []
dirt_objects = []
grass_objects = []
jumper_objects = []
portals = []
skull_objects = []
bumpy_objects = []
creature_objects=[]
tree_objects=[]
throne_objects=[]

Stages = [Stage(game_map[i], i) for i in range(5)]



def load_map(stage_number):
    y = 0
    dirt_objects.clear()
    grass_objects.clear()
    jumper_objects.clear()
    portals.clear()
    skull_objects.clear()
    bumpy_objects.clear()
    creature_objects.clear()
    tree_objects.clear()
    tile_rects.clear()
    throne_objects.clear()
    for layer in Stages[stage_number - 1].getmap():
        x = 0
        for tile in layer:
            if tile == '1':
                dirt_objects.append([x, y]) # 흰색 블럭

            if tile == '2':
                grass_objects.append([x, y]) # 검은색 블럭

            if tile == '3':
                jumper_objects.append(jumper_obj((x * 16, y * 16), 0))

            if tile == '4':
                jumper_objects.append(jumper_obj((x * 16, y * 16), 1))

            if tile == '5':
                portals.append(portal(x * 16, y * 16, 16, 64, 'portal_white'))

            if tile == '6':
                portals.append(portal(x * 16, y * 16, 16, 64, 'portal_black'))

            if tile == 's':
                skull=skull_obj(x * 16, y * 16, rd.randint(0,1))
                skull.setspeed(2)
                skull_objects.append(skull)

            if tile == 'b':
                bumpy=bumpy_obj(x * 16, y * 16, rd.randint(0,1))
                bumpy_objects.append(bumpy)

            if tile == 'c':
                creature=creature_obj(x*16, y*16, rd.randint(0,1))
                creature_objects.append(creature)

            if tile == 't':
                tree=tree_obj(x*16, y*16, rd.randint(0,1))
                tree_objects.append(tree)

            if tile=='7':
                throne=throne_obj((x*16,y*16),0)
                throne_objects.append(throne)
            if tile=='8':
                throne=throne_obj((x*16,y*16),1)
                throne_objects.append(throne)
            if tile not in ['0', '3', '4', '5', '6','7','8','s','b','c','t']:
                tile_rects.append(pygame.Rect(x * 16, y * 16, 16, 16))

            x += 1
        y += 1