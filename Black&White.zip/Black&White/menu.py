#!/usr/bin/python3.4
# Setup Python ----------------------------------------------- #
import pygame, sys
import BaseEngine_new as e
# Setup pygame/window ---------------------------------------- #
mainClock = pygame.time.Clock()
from pygame.locals import *
ex=False
setfps=60
setvolume=1

import load_map as l
pygame.init()
pygame.display.set_caption('Menu')
screen = pygame.display.set_mode((1080,720), 0, 32)
grass_volume_menu=0.2

font = pygame.font.SysFont(None, 20)


def draw_text(text, font, color, surface, x, y):
    textobj = font.render(text, 1, color)
    textrect = textobj.get_rect()
    textrect.topleft = (x, y)
    surface.blit(textobj, textrect)


option_image=pygame.transform.scale(pygame.image.load('options.png'),(200,100))
resume_image=pygame.transform.scale(pygame.image.load('resume.png'),(200,100))
quit_image=pygame.transform.scale(pygame.image.load('quit.png'),(200,100))
click = False

restart=False
stage_select=False
def main_menu():
    global stage_select,restart
    while True:
        pygame.display.set_caption('Main Menu')
        click = False
        for event in pygame.event.get():
            if event.type == QUIT:
                pygame.quit()
                sys.exit()
            if event.type == KEYDOWN:
                if event.key == K_ESCAPE:
                    pygame.quit()
                    sys.exit()
            if event.type == MOUSEBUTTONDOWN:
                if event.button == 1:
                    click = True
        screen.fill((255,255,255))
        myFont = pygame.font.SysFont("arial", 30, True, False)
        str=myFont.render("Tale of Black and White",True,(0,0,0))
        str_rect=str.get_rect()
        str_rect.center=(540,50)
        screen.blit(str,str_rect)

        # button_stageselect = pygame.Rect(0, 0, 300, 150)
        # button_stageselect.center = (540,600)
        # pygame.draw.rect(screen, (255, 0, 0), button_stageselect)
        # myFont = pygame.font.SysFont("arial", 30, True, False)
        # str_stageselect = myFont.render("STAGE SELECT", True, (255, 255, 255))
        # str_stageselect_rect = str_stageselect.get_rect()
        # str_stageselect_rect.center = (540,600)
        # screen.blit(str_stageselect, str_stageselect_rect)

        mx, my = pygame.mouse.get_pos()

        option_rect = option_image.get_rect()
        option_rect.center=(540,275)
        resume_rect=option_image.get_rect()
        resume_rect.center=(540,150)
        quit_rect=quit_image.get_rect()
        quit_rect.center=(540,400)
        stage_select_image=pygame.transform.scale(pygame.image.load('Stageselect.png'),(200,100))
        stage_select_image_rect=stage_select_image.get_rect()
        stage_select_image_rect.center=(540,650)
        restart_img = pygame.transform.scale(pygame.image.load('restart.png'), (200, 100))
        restart_img_rect = restart_img.get_rect()
        restart_img_rect.center = (540,525)


        if resume_rect.collidepoint((mx, my)):
            if click:
                break
        if option_rect.collidepoint((mx,my)):
            if click:
                options()
        if quit_rect.collidepoint((mx,my)):
            if click:
                pygame.quit()
                sys.exit()
        if restart_img_rect.collidepoint((mx,my)):
            if click:
                restart=True
                break
        # if button_stageselect.collidepoint((mx,my)):
        #     if click:
        #         e.SelectStage(l.Stages)
        #         break
        if stage_select_image_rect.collidepoint((mx,my)):
            if click:
                stage_select=True
                e.SelectStage(l.Stages)
                break

        screen.blit(resume_image,resume_rect)
        screen.blit(option_image,option_rect)
        screen.blit(quit_image,quit_rect)
        screen.blit(stage_select_image,stage_select_image_rect)
        screen.blit(restart_img,restart_img_rect)

        pygame.display.update()
        mainClock.tick(60)


def game():
    running = True
    while running:
        screen.fill((0, 0, 0))

        draw_text('game', font, (255, 255, 255), screen, 20, 20)
        for event in pygame.event.get():
            if event.type == QUIT:
                pygame.quit()
                sys.exit()
            if event.type == KEYDOWN:
                if event.key == K_ESCAPE:
                    running = False

        pygame.display.update()
        mainClock.tick(60)


def setframe():
    running = True
    global setfps
    while running:
        screen.fill((255,255,255))
        pygame.display.set_caption('Frame Settings')
        #draw_text('options', font, (255, 255, 255), screen, 20, 20)
        click = False
        for event in pygame.event.get():
            if event.type == QUIT:
                pygame.quit()
                sys.exit()
            if event.type == KEYDOWN:
                if event.key == K_ESCAPE:
                    running = False
            if event.type == MOUSEBUTTONDOWN:
                if event.button == 1:
                    click = True
        button_30fps=pygame.Rect(490,250,200,50)
        button_30fps.center=(490,250)
        pygame.draw.rect(screen,(255,0,0),button_30fps)
        myFont = pygame.font.SysFont("arial", 30, True, False)
        str_30fps = myFont.render("30 fps", True, (0, 0, 0))
        str_30fps_rect = str_30fps.get_rect()
        str_30fps_rect.center = (490, 250)
        screen.blit(str_30fps, str_30fps_rect)

        button_60fps = pygame.Rect(490, 500, 200, 50)
        button_60fps.center = (490, 500)
        pygame.draw.rect(screen, (0, 255, 0), button_60fps)
        myFont = pygame.font.SysFont("arial", 30, True, False)
        str_60fps = myFont.render("60 fps", True, (0, 0, 0))
        str_60fps_rect = str_60fps.get_rect()
        str_60fps_rect.center = (490, 500)
        screen.blit(str_60fps, str_60fps_rect)

        button_back = pygame.Rect(0, 0, 200, 50)
        button_back.center = (100, 25)
        pygame.draw.rect(screen, (255, 0, 0), button_back)
        myFont = pygame.font.SysFont("arial", 30, True, False)
        str_back = myFont.render("Back", True, (0, 0, 0))
        str_back_rect = str_back.get_rect()
        str_back_rect.center = (100, 25)
        screen.blit(str_back, str_back_rect)


        str_state=myFont.render(str(setfps)+"fps",True,(0,0,0))
        str_state_rect=str_state.get_rect()
        str_state_rect.center=(490,75)
        screen.blit(str_state,str_state_rect)
        mx,my=pygame.mouse.get_pos()
        if button_30fps.collidepoint((mx,my)):
            if click:
                setfps=30
        if button_60fps.collidepoint((mx,my)):
            if click:
                setfps=60
        if button_back.collidepoint((mx,my)):
            if click:
                break

        pygame.display.update()
        mainClock.tick(60)
def options():
    while True:
        pygame.display.set_caption('Options')
        screen.fill((255,255,255))
        click = False
        for event in pygame.event.get():
            if event.type == QUIT:
                pygame.quit()
                sys.exit()
            if event.type == KEYDOWN:
                if event.key == K_ESCAPE:
                    running = False
            if event.type == MOUSEBUTTONDOWN:
                if event.button == 1:
                    click = True
        button_Setframe = pygame.Rect(490, 250, 200, 50)
        button_Setframe.center = (490, 200)
        pygame.draw.rect(screen, (255, 0, 0), button_Setframe)
        myFont = pygame.font.SysFont("arial", 30, True, False)
        str_Setframe = myFont.render("Frame", True, (0, 0, 0))
        str_Setframe_rect = str_Setframe.get_rect()
        str_Setframe_rect.center = (490, 200)
        screen.blit(str_Setframe, str_Setframe_rect)

        button_back = pygame.Rect(0, 0, 200, 50)
        button_back.center = (100, 25)
        pygame.draw.rect(screen, (255, 0, 0), button_back)
        myFont = pygame.font.SysFont("arial", 30, True, False)
        str_back = myFont.render("Back", True, (0, 0, 0))
        str_back_rect = str_back.get_rect()
        str_back_rect.center = (100, 25)
        screen.blit(str_back, str_back_rect)

        button_sound = pygame.Rect(490, 500, 200, 50)
        button_sound.center = (490, 400)
        pygame.draw.rect(screen, (255, 0, 0), button_sound)
        myFont = pygame.font.SysFont("arial", 30, True, False)
        str_sound = myFont.render("Sound", True, (0, 0, 0))
        str_sound_rect = str_sound.get_rect()
        str_sound_rect.center = (490, 400)
        screen.blit(str_sound, str_sound_rect)

        mx,my=pygame.mouse.get_pos()
        if button_Setframe.collidepoint((mx,my)):
            if click:
                setframe()
        if button_back.collidepoint((mx,my)):
            if click:
                break
        if button_sound.collidepoint((mx,my)):
            if click:
                Setsound()
        pygame.display.update()
        mainClock.tick(60)

controller_x = 590
contoller_y = 200
controller_x1=590
effect_volume=1
def Setsound():
    import pygame
    global contoller_y,controller_x,setvolume,grass_volume_menu,controller_x1,effect_volume
    while True:
        pygame.display.set_caption('Sound Settings')
        screen.fill((255,255,255))

        click=False
        for event in pygame.event.get():
            if event.type == QUIT:
                pygame.quit()
                sys.exit()
            if event.type == KEYDOWN:
                if event.key == K_ESCAPE:
                    running = False
            if event.type == MOUSEBUTTONDOWN:
                if event.button == 1:
                    click = True

        button_back = pygame.Rect(0, 0, 200, 50)
        button_back.center = (100, 25)
        pygame.draw.rect(screen, (255, 0, 0), button_back)
        myFont = pygame.font.SysFont("arial", 30, True, False)
        str_back = myFont.render("Back", True, (0, 0, 0))
        str_back_rect = str_back.get_rect()
        str_back_rect.center = (100, 25)
        screen.blit(str_back, str_back_rect)

        button_touch=pygame.Rect(490,0,300,50)
        button_touch.center=(490,200)
        pygame.draw.rect(screen,(255,255,255),button_touch)

        button_control=pygame.Rect(490,0,200,5)
        button_control.center=(490,200)
        pygame.draw.rect(screen,(0,0,255),button_control)

        controller=pygame.transform.scale(pygame.image.load('circle.png'),(5,5))
        controller_rect=controller.get_rect()
        controller_rect.center=(controller_x,200)
        screen.blit(controller,controller_rect)

        button_music_soundboard=pygame.Rect(200,100,200,50)
        button_music_soundboard.center=(200,200)
        pygame.draw.rect(screen,(0,255,0),button_music_soundboard)
        str_music_soundboard=myFont.render('Music volume',True,(0,0,0))
        str_music_soundboard_rect=str_music_soundboard.get_rect()
        str_music_soundboard_rect.center=(200,200)
        screen.blit(str_music_soundboard,str_music_soundboard_rect)

        button_touch1 = pygame.Rect(490, 0, 300, 50)
        button_touch1.center = (490, 450)
        pygame.draw.rect(screen, (255, 255, 255), button_touch1)

        button_control1 = pygame.Rect(490, 0, 200, 5)
        button_control1.center = (490, 450)
        pygame.draw.rect(screen, (0, 0, 255), button_control1)

        controller1 = pygame.transform.scale(pygame.image.load('circle.png'), (5, 5))
        controller1_rect = controller1.get_rect()
        controller1_rect.center = (controller_x1, 450)
        screen.blit(controller1, controller1_rect)

        button_music_soundboard1 = pygame.Rect(200, 100, 200, 50)
        button_music_soundboard1.center = (200, 450)
        pygame.draw.rect(screen, (0, 255, 0), button_music_soundboard1)
        str_music_soundboard1 = myFont.render('Effect volume', True, (0, 0, 0))
        str_music_soundboard1_rect = str_music_soundboard1.get_rect()
        str_music_soundboard1_rect.center = (200, 450)
        screen.blit(str_music_soundboard1, str_music_soundboard1_rect)



        if button_back.collidepoint(pygame.mouse.get_pos()):
            if click:
                break
        if button_control.collidepoint(pygame.mouse.get_pos()) or button_touch.collidepoint(pygame.mouse.get_pos()):
            if click:
                x,y=pygame.mouse.get_pos()
                if x>590:
                    controller_x=590
                elif x<390:
                    controller_x=390
                else:
                    controller_x=x
                setvolume=(controller_x-390)/200
                pygame.mixer.music.set_volume(setvolume)
        if button_control1.collidepoint(pygame.mouse.get_pos()) or button_touch1.collidepoint(pygame.mouse.get_pos()):
            if click:
                x,y=pygame.mouse.get_pos()
                if x>590:
                    controller_x1=590
                elif x<390:
                    controller_x1=390
                else:
                    controller_x1=x
                effect_volume=(controller_x1-390)/200
        pygame.display.update()
        mainClock.tick(60)
class Button:
    def __init__(self,str,fontsize,color,centerlocation):
        self.purpose=str
        self.fontsize=fontsize
        self.color=color
        self.center=centerlocation